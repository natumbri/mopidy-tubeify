import re

from bs4 import BeautifulSoup as bs
from mopidy_youtube.comms import Client
from mopidy_youtube.yt_matcher import search_and_get_best_match

from mopidy_tubeify import logger

class Apple(Client):
    def get_user_details(self, user):
        pass

    def get_user_playlists(self, user):
        pass

    def get_playlist_details(self, playlists):
        def job(playlist):
            endpoint = f"https://music.apple.com/us/playlist/{playlist}"
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36"
            }
            data = self.session.get(endpoint, headers=headers)
            soup = bs(data.text, "html5lib")
            playlist_name = soup.find("title").text
            return {"name": playlist_name, "id": playlist}

        results = []

        # does apple uses a captcha? be careful before going multi-threaded
        [results.append(job(playlist)) for playlist in playlists]

        return results

    def get_playlist_tracks(self, playlist):
        endpoint = f"https://music.apple.com/us/playlist/{playlist}"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36"
        }
        data = self.session.get(endpoint, headers=headers)
        soup = bs(data.text, "html5lib")

        # this script seems to have a json record of all the tracks
        # in the playlist, with information including title, duration,
        # album, etc for each
        track_list = (
            soup.find("script", {"id": "shoebox-media-api-cache-amp-music"})
            .text.encode("ascii", "ignore")
            .decode("unicode_escape")
        )

        # pending implementation of proper bs4/json/dict approach, regex for
        # isrc seems to work.
        isrc_pattern = re.compile(r'"isrc"\:"(?P<isrc>.{12})"')
        isrcs = [match["isrc"] for match in isrc_pattern.finditer(track_list)]

        track_dict = {}
        for index, isrc in enumerate(isrcs):

            song_name = None
            # (
            #     **get song_name out of track_list somehow**
            # )
            song_artists = None
            # [
            #     **get song_artists out of track_list somehow**
            # ]
            song_duration = None
            # (
            #     **get song_duration out of track_list somehow**
            # )

            track_dict[index] = {
                "song_name": song_name,
                "song_artists": song_artists,
                "song_duration": song_duration,
                "isrc": isrc,
            }

        tracks = list(track_dict.values())

        return search_and_get_best_match(tracks)

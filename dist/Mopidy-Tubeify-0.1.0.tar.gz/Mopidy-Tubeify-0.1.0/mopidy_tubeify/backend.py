import json

import pykka
from cachetools import TTLCache, cached
from mopidy import backend, httpclient
from mopidy.models import Ref

from mopidy_tubeify import Extension, logger
from mopidy_tubeify.data import extract_playlist_id
from mopidy_tubeify.apple import Apple
from mopidy_tubeify.spotify import Spotify
from mopidy_tubeify.tidal import Tidal


class TubeifyBackend(pykka.ThreadingActor, backend.Backend):
    def __init__(self, config, audio):
        super().__init__()
        self.config = config
        self.library = TubeifyLibraryProvider(backend=self)
        self.applemusic_users = config["tubeify"]["applemusic_users"]
        self.applemusic_playlists = config["tubeify"]["applemusic_playlists"]
        self.spotify_users = config["tubeify"]["spotify_users"]
        self.tidal_playlists = config["tubeify"]["tidal_playlists"]
        self.uri_schemes = ["tubeify"]
        self.user_agent = "{}/{}".format(Extension.dist_name, Extension.version)

    def on_start(self):
        proxy = httpclient.format_proxy(self.config["proxy"])
        headers = {"user-agent": httpclient.format_user_agent(self.user_agent)}
        if self.config["tubeify"]["applemusic_users"] or self.config["tubeify"]["applemusic_playlists"]:
            self.library.apple = Apple(proxy, headers)
        if self.config["tubeify"]["spotify_users"]:
            self.library.spotify = Spotify(proxy, headers)
        if self.config["tubeify"]["tidal_playlists"]:
            self.library.tidal = Tidal()
            self.library.tidal.session = requests.Session()


class TubeifyLibraryProvider(backend.LibraryProvider):

    """
    Called when root_directory is set to [insert description]
    When enabled makes possible to browse the users listed in
    config["tubeify"]["applemusic_users"] and to browse their
    public playlists and the separate tracks those playlists.
    """

    root_directory = Ref.directory(uri="tubeify:browse", name="Tubeify")

    cache_max_len = 4000
    cache_ttl = 21600

    apple_cache = TTLCache(maxsize=cache_max_len, ttl=cache_ttl)

    @cached(cache=apple_cache)
    def browse(self, uri):

        # if we're browsing, return a list of directories
        if uri == "tubeify:browse":
            return [
                Ref.directory(uri="tubeify:all:users", name="All Service Users"),
                Ref.directory(uri="tubeify:all:playlists", name="All Service Playlists"),
                # Ref.directory(uri="tubeify:apple:users", name="Apple Users"),
                Ref.directory(
                    uri="tubeify:apple:playlists", name="Apple Playlists"
                ),
                Ref.directory(uri="tubeify:spotify:users", name="Spotify Users"),
                Ref.directory(uri="tubeify:tidal:playlists", name="Tidal Playlists"),
            ]

        # if we're looking at service users, return a list of the users
        # as Ref.directory: extract names and uris, return a list of Refs
        match = re.match(r'tubeify:(?P<service>.+):(?P<kind>.+)$', uri)

        if match and match.get('kind') == "user":
            service = match['service']
            service_method = getattr(self, service)
            listofusers = getattr(self.backend, f'{service}_users')            
            userrefs = []
            for user in listofusers:
                user_details = service_method.get_user_details(user)
                userrefs.append(
                    Ref.directory(
                        uri=f"tubeify:{service}_user:{user}",
                        name=user_details["display_name"],
                    )
                )
            return userrefs

        # if we're looking at service playlists, return a list of the playlists
        # as Ref.directory: extract names and uris, return a list of Refs
        if match and match.get('kind') == "playlist":
            service = match['service']  # doesn't deal with 'all'!
            service_method = getattr(self, service)
            listofplaylists = getattr(self.backend, f'{service}_playlists')
            playlistrefs = []
            playlists = service_method.get_playlist_details(
                listofplaylists
            )
            playlistrefs = [
                Ref.directory(
                    uri=f"tubeify:{service}_playlist:{playlist['id']}",
                    name=playlist["name"],
                )
                for playlist in playlists
                if playlist["id"]
            ]
            return playlistrefs

        # if we're looking at a user, return a list of the user's playlists
        elif extract_user_id(uri):
            service, user_uri = extract_user_id(uri)
            logger.debug(f"browse {service} user {user_uri}")
            playlistrefs = []
            service_method = getattr(self, service)
            playlists = service_method.get_user_playlists(
                extract_user_id(uri)
            )
            playlistrefs = [
                Ref.directory(
                    uri=f"tubify:{service}_playlist:{playlist['id']}",
                    name=playlist["name"],
                )
                for playlist in playlists
                if playlist["id"]
            ]
            return playlistrefs

        # if we're looking at a playlist, return a list of the playlist's tracks
        elif extract_playlist_id(uri):
            service, playlist_uri = extract_playlist_id(uri)
            logger.debug(f"browse {service} playlist {playlist_uri}")
            trackrefs = []
            service_method = getattr(self, service)
            tracks = service_method.get_playlist_tracks(
                extract_playlist_id(uri)
            )

            trackrefs = [
                Ref.track(
                    uri=f"yt:video:{track['videoId']}",
                    name=track["title"],
                )
                for track in tracks
                if "videoId" in track
            ]

            # include ytmusic data for all tracks as preload data in the uri
            # for the first track.  There is surely a better way to do this.
            # It breaks the first track in the musicbox_webclient
            trackrefs[0] = Ref.track(
                uri=(
                    f"yt:video:{tracks[0]['videoId']}"
                    f":preload:"
                    f"{json.dumps([track for track in tracks if track is not None])}"
                ),
                name=tracks[0]["title"],
            )
            return trackrefs
